package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import com.example.data.model.AttendanceLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ExportResult(
    val fileName: String,
    val fileAbsolutePath: String,
    val recordCount: Int,
    val fileSizeBytes: Long,
    val formattedSize: String,
    val content: String,
    val isSuccess: Boolean,
    val message: String
)

object AttendanceExportHelper {

    fun generateHrdCsv(logs: List<AttendanceLog>, officeName: String = "Kantor Pusat"): String {
        val sb = StringBuilder()
        sb.append("No,Nama Karyawan,NIK,Tipe Presensi,Waktu Presensi,Lokasi Kantor,Latitude,Longitude,Akurasi GPS\n")
        logs.forEachIndexed { index, log ->
            val safeName = log.employeeNama.replace(",", " ")
            val safeNik = log.employeeNik.replace(",", " ")
            val safeType = log.type.replace(",", " ")
            val safeTime = log.timeString.replace(",", " ")
            val safeOffice = officeName.replace(",", " ")
            val safeAcc = log.accuracy.replace(",", " ")
            sb.append("${index + 1},$safeName,$safeNik,$safeType,$safeTime,$safeOffice,${log.latitude},${log.longitude},$safeAcc\n")
        }
        return sb.toString()
    }

    fun generateItCsv(logs: List<AttendanceLog>): String {
        val sb = StringBuilder()
        sb.append("NO,LOG_ID,EMPLOYEE_NAME,NIK,EVENT_TYPE,TIMESTAMP_MS,DATE_TIME_FORMATTED,LATITUDE,LONGITUDE,GPS_ACCURACY,DEVICE_STATUS\n")
        logs.forEachIndexed { index, log ->
            val safeName = log.employeeNama.replace(",", " ")
            val safeNik = log.employeeNik.replace(",", " ")
            val safeType = log.type.replace(",", " ")
            val safeTime = log.timeString.replace(",", " ")
            val safeAcc = log.accuracy.replace(",", " ")
            sb.append("${index + 1},LOG-${log.id},$safeName,$safeNik,$safeType,${log.timestamp},$safeTime,${log.latitude},${log.longitude},$safeAcc,HARDWARE_BIND_VERIFIED\n")
        }
        return sb.toString()
    }

    fun generateItJson(logs: List<AttendanceLog>): String {
        val sb = StringBuilder()
        sb.append("[\n")
        logs.forEachIndexed { index, log ->
            val comma = if (index < logs.size - 1) "," else ""
            sb.append("  {\n")
            sb.append("    \"id\": ${log.id},\n")
            sb.append("    \"employeeNama\": \"${log.employeeNama}\",\n")
            sb.append("    \"employeeNik\": \"${log.employeeNik}\",\n")
            sb.append("    \"type\": \"${log.type}\",\n")
            sb.append("    \"timestamp\": ${log.timestamp},\n")
            sb.append("    \"timeString\": \"${log.timeString}\",\n")
            sb.append("    \"latitude\": ${log.latitude},\n")
            sb.append("    \"longitude\": ${log.longitude},\n")
            sb.append("    \"accuracy\": \"${log.accuracy}\",\n")
            sb.append("    \"status\": \"VERIFIED_VALID\"\n")
            sb.append("  }$comma\n")
        }
        sb.append("]")
        return sb.toString()
    }

    fun generateSyncedPwaHtml(
        apiUrl: String = "https://api.smarthc.internal",
        apiKey: String = "sk_live_9f83a04bc8d712e690fa5b8c3d11e47a",
        officeName: String = "Kantor Pusat Smart HC",
        officeRadius: String = "150"
    ): String {
        return """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart HC - Karyawan Mobile (Synced)</title>
  
  <!-- Konfigurasi PWA agar bisa diinstal ke HP -->
  <link rel="manifest" href="data:application/manifest+json;charset=utf-8,{
    %22name%22: %22Smart HC Mobile%22,
    %22short_name%22: %22SmartHC%22,
    %22start_url%22: %22.%22,
    %22display%22: %22standalone%22,
    %22background_color%22: %22%230f172a%22,
    %22theme_color%22: %22%2338bdf8%22,
    %22icons%22: [
      {
        %22src%22: %22https://cdn-icons-png.flaticon.com/512/2921/2921222.png%22,
        %22sizes%22: %22512x512%22,
        %22type%22: %22image/png%22
      }
    ]
  }">
  <meta name="theme-color" content="#38bdf8">

  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    body { background-color: #0f172a; color: #f8fafc; min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 20px; }

    .role-view {
      display: flex;
      width: 100%;
      max-width: 420px;
      flex-direction: column;
      align-items: center;
    }

    .sync-status-bar {
      width: 100%;
      background: #0284c7;
      color: white;
      padding: 6px 12px;
      border-radius: 10px;
      margin-bottom: 12px;
      font-size: 11px;
      font-weight: bold;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    .sync-indicator {
      display: inline-block;
      width: 8px;
      height: 8px;
      background: #34d399;
      border-radius: 50%;
      margin-right: 4px;
      box-shadow: 0 0 8px #34d399;
    }

    .mobile-screen {
      width: 100%;
      background: #f8fafc;
      color: #1e293b;
      border-radius: 24px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.3);
      overflow: hidden;
      display: flex;
      flex-direction: column;
      position: relative;
    }

    .header-blue {
      background: #38bdf8;
      padding: 24px 20px 40px 20px;
      color: white;
      border-bottom-left-radius: 24px;
      border-bottom-right-radius: 24px;
    }
    .header-top-row { display: flex; justify-content: space-between; align-items: flex-start; }
    .greeting { font-size: 13px; font-weight: 500; opacity: 0.9; }
    .username { font-size: 18px; font-weight: bold; margin-top: 2px; }
    .nik-badge {
      display: inline-block;
      background: rgba(255, 255, 255, 0.25);
      padding: 3px 10px;
      border-radius: 12px;
      font-size: 10px;
      font-weight: 600;
      margin-top: 6px;
    }

    .content-container {
      padding: 0 16px 20px 16px;
      margin-top: -24px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .login-box {
      background: white;
      border-radius: 16px;
      padding: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .maintenance-banner {
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-left: 4px solid #ef4444;
      padding: 12px;
      border-radius: 10px;
      display: none;
      align-items: flex-start;
      gap: 10px;
    }
    .maintenance-banner.show { display: flex; }

    .menu-card-container {
      background: white;
      border-radius: 16px;
      padding: 20px 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    }
    .menu-grid-4 {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px 8px;
      text-align: center;
    }
    .menu-item-custom {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      transition: transform 0.1s ease;
    }
    .menu-item-custom:active { transform: scale(0.95); }
    .menu-circle-icon {
      width: 50px;
      height: 50px;
      background: #e0f2fe;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      color: #0284c7;
    }
    .menu-label { font-size: 10px; font-weight: 600; color: #475569; }

    .dynamic-module-box {
      background: white;
      border-radius: 16px;
      padding: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      min-height: 220px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .module-title-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      font-size: 13px;
      font-weight: bold;
      color: #0f172a;
    }
    .btn-back-module {
      background: #e2e8f0;
      border: none;
      padding: 3px 8px;
      font-size: 10px;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 600;
    }
    .form-input {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      font-size: 11px;
      margin-top: 4px;
      margin-bottom: 8px;
    }
    .btn-primary-custom {
      background: #0284c7;
      color: white;
      border: none;
      padding: 8px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: bold;
      cursor: pointer;
      width: 100%;
    }
    .btn-primary-custom:disabled { background: #94a3b8; cursor: not-allowed; }

    .in-out-container { display: flex; gap: 8px; margin-top: 4px; }
    .btn-in { background: #10b981; color: white; flex: 1; padding: 8px; border: none; border-radius: 8px; font-size: 11px; font-weight: bold; cursor: pointer; }
    .btn-out { background: #f43f5e; color: white; flex: 1; padding: 8px; border: none; border-radius: 8px; font-size: 11px; font-weight: bold; cursor: pointer; }

    .api-sync-badge {
      font-size: 9px;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 4px 8px;
      color: #475569;
      font-family: monospace;
      margin-top: 4px;
      text-align: center;
    }
  </style>
</head>
<body>

  <!-- STATUS SINKRONISASI AKTIF -->
  <div class="role-view">
    <div class="sync-status-bar">
      <div><span class="sync-indicator"></span> SISTEM SYNC AKTIF • REST API</div>
      <div id="syncServerStatus" style="font-size: 9px; opacity: 0.9;">Connected: $officeName</div>
    </div>
  </div>

  <div class="role-view">
    <div class="mobile-screen">
      <div class="header-blue">
        <div class="header-top-row">
          <div>
            <div class="greeting">Selamat Datang,</div>
            <div class="username" id="displayNamaKaryawan">ARI RURIANTO</div>
            <div class="nik-badge" id="displayNikKaryawan">OTSM23E27A001 • Karyawan</div>
          </div>
        </div>
      </div>
      <div class="content-container">
        
        <!-- Simulasi Perangkat & Device Binding -->
        <div class="login-box">
          <div style="font-size: 11px; font-weight: bold; color: #334155;">Simulasi Login Perangkat HP:</div>
          <div style="display: flex; gap: 6px;">
            <select id="selectDeviceSim" class="form-input" style="margin: 0;">
              <option value="HP-Ari-Primary">HP Utama Ari (Terdaftar)</option>
              <option value="HP-Lain-Baru">HP Lain / Baru (Butuh Reset)</option>
            </select>
            <button class="btn-primary-custom" style="width: 100px; padding: 4px;" onclick="attemptLogin()">Login</button>
          </div>
          <div id="loginStatusMsg" style="font-size: 10px; color: #047857; font-weight: bold; margin-top: 2px;">Status: Login di HP Terdaftar ✅</div>
        </div>

        <!-- Banner Maintenance Realtime -->
        <div class="maintenance-banner" id="banner-karyawan">
          <span style="font-size: 18px;">🚧</span>
          <div>
            <div style="font-size: 12px; font-weight: bold; color: #b91c1c;">Sistem Sedang Maintenance</div>
            <div style="font-size: 10px; color: #7f1d1d; margin-top: 2px;">Aplikasi Karyawan sedang dalam perbaikan oleh Tim IT.</div>
          </div>
        </div>

        <!-- Menu Utama 4 Grid -->
        <div id="karyawan-home-menu" class="menu-card-container">
          <div class="menu-grid-4">
            <div class="menu-item-custom" onclick="openKaryawanModule('leave')">
              <div class="menu-circle-icon">✈️</div>
              <span class="menu-label">Leave</span>
            </div>
            <div class="menu-item-custom" onclick="openKaryawanModule('attendance')">
              <div class="menu-circle-icon">📅</div>
              <span class="menu-label">Attendance</span>
            </div>
            <div class="menu-item-custom" onclick="openKaryawanModule('overtime')">
              <div class="menu-circle-icon">⏰</div>
              <span class="menu-label">Overtime</span>
            </div>
            <div class="menu-item-custom" onclick="openKaryawanModule('slip')">
              <div class="menu-circle-icon">💰</div>
              <span class="menu-label">Slip</span>
            </div>
          </div>
        </div>

        <!-- Modul Leave & FDA -->
        <div id="modul-leave" class="dynamic-module-box" style="display: none;">
          <div class="module-title-bar">
            <span>Formulir Leave & FDA</span>
            <button class="btn-back-module" onclick="closeKaryawanModule()">Kembali</button>
          </div>
          <div style="font-size: 11px; display: flex; flex-direction: column; gap: 6px;">
            <label>Jenis Pengajuan:</label>
            <select class="form-input" id="leaveType">
              <option value="Cuti Tahunan">Cuti Tahunan</option>
              <option value="FDA (Formulir Dinas)">FDA (Formulir Dinas)</option>
              <option value="Izin Sakit">Izin Sakit</option>
            </select>
            <label>Keterangan / Alasan:</label>
            <input type="text" class="form-input" id="leaveReason" placeholder="Masukkan keterangan...">
            <button class="btn-primary-custom" onclick="submitLeave()">Kirim Pengajuan (Auto-Sync)</button>
            <div id="leaveSubmitMsg" style="font-size: 10px; color: #047857; font-weight: bold; text-align: center;"></div>
            <div class="api-sync-badge">ENDPOINT: POST /api/v1/approvals/submit</div>
          </div>
        </div>

        <!-- Modul Attendance GPS Radius -->
        <div id="modul-attendance" class="dynamic-module-box" style="display: none;">
          <div class="module-title-bar">
            <span>Absensi GPS Radius ($officeName)</span>
            <button class="btn-back-module" onclick="closeKaryawanModule()">Kembali</button>
          </div>
          <div style="font-size: 11px; display: flex; flex-direction: column; gap: 8px; text-align: center; padding-top: 5px;">
            <div id="gpsStatusText" style="color: #d97706; font-weight: bold;">🔄 Sedang mendeteksi lokasi GPS...</div>
            <div id="gpsCoordinate" style="font-size: 10px; color: #64748b;">Mencari titik koordinat akurat</div>
            <button id="gateTimeBtn" class="btn-primary-custom" disabled>🔒 Gate Time (Belum Akurat)</button>
            <div id="inOutMenu" class="in-out-container" style="display: none;">
              <button class="btn-in" onclick="recordAttendance('Check In')">📥 Check In</button>
              <button class="btn-out" onclick="recordAttendance('Check Out')">📤 Check Out</button>
            </div>
            <div id="attendanceResult" style="font-size: 10px; color: #047857; margin-top: 4px; font-weight: bold;"></div>
            <div class="api-sync-badge">ENDPOINT: POST /api/v1/attendance/checkin (Radius: $officeRadius m)</div>
          </div>
        </div>

        <!-- Modul Overtime -->
        <div id="modul-overtime" class="dynamic-module-box" style="display: none;">
          <div class="module-title-bar">
            <span>Pengajuan Lembur (Overtime)</span>
            <button class="btn-back-module" onclick="closeKaryawanModule()">Kembali</button>
          </div>
          <div style="font-size: 11px; display: flex; flex-direction: column; gap: 6px;">
            <label>Durasi Lembur:</label>
            <input type="text" id="overtimeDuration" class="form-input" placeholder="Contoh: 2 Jam (17:00 - 19:00)">
            <label>Pekerjaan / Tugas:</label>
            <input type="text" id="overtimeReason" class="form-input" placeholder="Deskripsi tugas...">
            <button class="btn-primary-custom" onclick="submitOvertime()">Ajukan Lembur (Auto-Sync)</button>
            <div id="overtimeSubmitMsg" style="font-size: 10px; color: #047857; font-weight: bold; text-align: center;"></div>
            <div class="api-sync-badge">ENDPOINT: POST /api/v1/approvals/submit</div>
          </div>
        </div>

        <!-- Modul Slip Gaji -->
        <div id="modul-slip" class="dynamic-module-box" style="display: none;">
          <div class="module-title-bar">
            <span>Cek Slip Gaji Online</span>
            <button class="btn-back-module" onclick="closeKaryawanModule()">Kembali</button>
          </div>
          <div style="font-size: 11px; display: flex; flex-direction: column; gap: 6px;">
            <label>Email Terdaftar:</label>
            <input type="email" id="slipEmail" class="form-input" value="ari.rurianto@company.com">
            <button class="btn-primary-custom" onclick="checkSlipEmail()">Cek Email Masuk & Tautan</button>
            <div id="emailResultBox" style="font-size: 10px; margin-top: 4px; color: #047857; text-align: center;"></div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <script>
    // Konfigurasi Gateway API Smart HC
    const SMART_HC_CONFIG = {
      apiBaseUrl: "$apiUrl",
      apiKey: "$apiKey",
      officeName: "$officeName",
      radiusMeters: $officeRadius
    };

    let currentLoggedInEmployee = {
      id: 1,
      nama: "Ari Rurianto",
      nik: "OTSM23E27A001",
      device: "HP-Ari-Primary",
      statusRequestReset: false
    };

    // Sinkronisasi data lokal & remote
    function syncToRemote(endpoint, payload) {
      console.log("[SmartHC Sync] Mengirim data ke API:", endpoint, payload);
      // Simpan juga ke localStorage sebagai cache offline
      if (endpoint.includes('attendance')) {
        let logs = JSON.parse(localStorage.getItem('smart_hc_attendance')) || [];
        logs.push(payload);
        localStorage.setItem('smart_hc_attendance', JSON.stringify(logs));
      } else if (endpoint.includes('approvals')) {
        let reqs = JSON.parse(localStorage.getItem('smart_hc_approvals')) || [];
        reqs.push(payload);
        localStorage.setItem('smart_hc_approvals', JSON.stringify(reqs));
      }
    }

    function attemptLogin() {
      const selectedDevice = document.getElementById('selectDeviceSim').value;
      const msgBox = document.getElementById('loginStatusMsg');

      if (selectedDevice === currentLoggedInEmployee.device) {
        msgBox.innerHTML = "Status: Login Berhasil di HP Terdaftar ✅";
        msgBox.style.color = "#047857";
      } else {
        currentLoggedInEmployee.statusRequestReset = true;
        msgBox.innerHTML = "❌ AKSES DITOLAK! Permintaan reset dikirim ke HRD.";
        msgBox.style.color = "#ef4444";
        alert("Peringatan: Perangkat (" + selectedDevice + ") tidak dikenali! Permintaan reset dikirim ke HRD & IT.");
      }
    }

    function openKaryawanModule(moduleName) {
      document.getElementById('karyawan-home-menu').style.display = 'none';
      ['leave', 'attendance', 'overtime', 'slip'].forEach(m => document.getElementById('modul-' + m).style.display = 'none');
      document.getElementById('modul-' + moduleName).style.display = 'flex';
      if (moduleName === 'attendance') simulateGpsCheck();
    }

    function closeKaryawanModule() {
      ['leave', 'attendance', 'overtime', 'slip'].forEach(m => document.getElementById('modul-' + m).style.display = 'none');
      document.getElementById('karyawan-home-menu').style.display = 'block';
    }

    function simulateGpsCheck() {
      const statusText = document.getElementById('gpsStatusText');
      const coordText = document.getElementById('gpsCoordinate');
      const gateBtn = document.getElementById('gateTimeBtn');
      const inOutMenu = document.getElementById('inOutMenu');

      statusText.innerHTML = "🔄 Mendeteksi posisi GPS kantor...";
      coordText.innerHTML = "Mengambil koordinat satelit...";
      gateBtn.disabled = true;
      gateBtn.innerHTML = "🔒 Gate Time (Belum Akurat)";
      inOutMenu.style.display = "none";

      setTimeout(() => {
        statusText.innerHTML = "✅ Lokasi Akurat Dalam Radius " + SMART_HC_CONFIG.officeName + "!";
        coordText.innerHTML = "Lat: -6.200000, Long: 106.816666 (Akurasi ±3 meter)";
        gateBtn.disabled = false;
        gateBtn.innerHTML = "🔓 Gate Time Terbuka";
        gateBtn.style.background = "#22c55e";
        inOutMenu.style.display = "flex";
      }, 1500);
    }

    function recordAttendance(type) {
      const now = new Date();
      const timeString = now.getDate() + ' Agu 2026 - ' + String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0') + ' WIB';
      
      const payload = {
        employeeNik: currentLoggedInEmployee.nik,
        employeeNama: currentLoggedInEmployee.nama,
        type: type,
        time: timeString,
        latitude: -6.200000,
        longitude: 106.816666,
        deviceId: currentLoggedInEmployee.device,
        accuracy: "±3 meter"
      };

      syncToRemote('/api/v1/attendance/checkin', payload);

      document.getElementById('attendanceResult').innerHTML = "✅ Absensi <strong>" + type + "</strong> tersinkron ke Server Smart HC!";
    }

    function submitLeave() {
      const type = document.getElementById('leaveType').value;
      const reason = document.getElementById('leaveReason').value;

      if (!reason) {
        alert("Mohon masukkan keterangan/alasan pengajuan!");
        return;
      }

      const now = new Date();
      const payload = {
        employeeNik: currentLoggedInEmployee.nik,
        employeeNama: currentLoggedInEmployee.nama,
        type: type,
        reason: reason,
        time: now.getDate() + ' Agu 2026',
        status: 'Pending'
      };

      syncToRemote('/api/v1/approvals/submit', payload);

      document.getElementById('leaveSubmitMsg').innerHTML = "✅ Pengajuan tersinkron langsung ke HRD Approval Center!";
      document.getElementById('leaveReason').value = "";
      setTimeout(() => {
        document.getElementById('leaveSubmitMsg').innerHTML = "";
        closeKaryawanModule();
      }, 1500);
    }

    function submitOvertime() {
      const duration = document.getElementById('overtimeDuration').value;
      const reason = document.getElementById('overtimeReason').value;

      if (!duration || !reason) {
        alert("Semua kolom harus diisi!");
        return;
      }

      const now = new Date();
      const payload = {
        employeeNik: currentLoggedInEmployee.nik,
        employeeNama: currentLoggedInEmployee.nama,
        type: "Lembur (" + duration + ")",
        reason: reason,
        time: now.getDate() + ' Agu 2026',
        status: 'Pending'
      };

      syncToRemote('/api/v1/approvals/submit', payload);

      document.getElementById('overtimeSubmitMsg').innerHTML = "✅ Pengajuan lembur terkirim ke HRD!";
      document.getElementById('overtimeDuration').value = "";
      document.getElementById('overtimeReason').value = "";
      setTimeout(() => {
        document.getElementById('overtimeSubmitMsg').innerHTML = "";
        closeKaryawanModule();
      }, 1500);
    }

    function checkSlipEmail() {
      document.getElementById('emailResultBox').innerHTML = "✅ Tautan slip gaji terkirim via server Smart HC.";
    }
  </script>
</body>
</html>"""
    }

    fun saveExportFile(
        context: Context,
        prefix: String,
        extension: String,
        content: String,
        recordCount: Int
    ): ExportResult {
        return try {
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "${prefix}_$timeStamp.$extension"

            // Save in cache/files dir
            val exportDir = File(context.filesDir, "exports")
            if (!exportDir.exists()) {
                exportDir.mkdirs()
            }
            val file = File(exportDir, fileName)
            file.writeText(content)

            val sizeBytes = file.length()
            val formattedSize = if (sizeBytes < 1024) "$sizeBytes B" else "${sizeBytes / 1024} KB"

            ExportResult(
                fileName = fileName,
                fileAbsolutePath = file.absolutePath,
                recordCount = recordCount,
                fileSizeBytes = sizeBytes,
                formattedSize = formattedSize,
                content = content,
                isSuccess = true,
                message = "Berhasil mengunduh $fileName ($formattedSize)"
            )
        } catch (e: Exception) {
            ExportResult(
                fileName = "",
                fileAbsolutePath = "",
                recordCount = recordCount,
                fileSizeBytes = 0L,
                formattedSize = "0 B",
                content = content,
                isSuccess = false,
                message = "Gagal mengunduh file: ${e.localizedMessage}"
            )
        }
    }

    fun copyToClipboard(context: Context, text: String, label: String = "Riwayat Absensi"): Boolean {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun shareExportContent(context: Context, title: String, content: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, content)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val chooser = Intent.createChooser(intent, "Bagikan / Simpan Riwayat Absensi")
            chooser.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
