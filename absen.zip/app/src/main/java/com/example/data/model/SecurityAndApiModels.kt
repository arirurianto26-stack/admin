package com.example.data.model

data class ApiKeyInfo(
    val id: String,
    val name: String,
    val key: String,
    val role: String, // "Read-Only", "Full-Access", "ERP Sync"
    val createdDate: String,
    val lastUsed: String,
    val isActive: Boolean,
    val rateLimitRpm: Int = 60
)

data class ApiEndpointDef(
    val id: String,
    val method: String, // "GET", "POST", "DELETE"
    val path: String,
    val title: String,
    val description: String,
    val defaultPayload: String = "",
    val category: String // "Karyawan", "Absensi", "Approval", "Sistem"
)

data class ApiResponseResult(
    val statusCode: Int,
    val statusText: String,
    val latencyMs: Long,
    val headers: Map<String, String>,
    val jsonBody: String,
    val isSuccess: Boolean,
    val signatureHmac: String = ""
)

data class SecurityIncident(
    val id: String,
    val timestamp: Long,
    val timeFormatted: String,
    val eventType: String, // "MOCK_GPS_BLOCKED", "DEVICE_MISMATCH", "HMAC_VERIFIED", "ROOT_CHECK", "API_REQUEST"
    val severity: String, // "INFO", "WARNING", "DANGER"
    val details: String,
    val sourceIp: String = "192.168.1.104",
    val deviceId: String = "HP-Target"
)

data class SecurityPolicyConfig(
    val antiMockGpsEnabled: Boolean = true,
    val rootDetectionEnabled: Boolean = true,
    val hmacSigningRequired: Boolean = true,
    val deviceBindingStrict: Boolean = true,
    val bruteForceProtection: Boolean = true,
    val autoLogoutMinutes: Int = 15,
    val apiRateLimitRpm: Int = 60,
    val ipWhitelistEnabled: Boolean = false
)

data class SecurityCheckItem(
    val id: String,
    val title: String,
    val category: String, // "Device Integrity", "Cryptographic Shield", "Geofence Armor", "API Gateway", "Data Privacy"
    val isPassed: Boolean,
    val scoreImpact: Int,
    val details: String,
    val recommendation: String
)

data class SecurityAuditResult(
    val score: Int, // 0 - 100
    val grade: String, // "A+ (Enterprise)", "A", "B", "C"
    val passedChecks: Int,
    val totalChecks: Int,
    val scanTimestamp: Long,
    val scanTimeFormatted: String,
    val checkDetails: List<SecurityCheckItem>
)
