package com.example.data.api

import com.example.data.model.ApiEndpointDef
import com.example.data.model.ApiResponseResult
import com.example.data.model.ApprovalRequest
import com.example.data.model.AttendanceLog
import com.example.data.model.Employee
import com.example.data.model.SecurityPolicyConfig
import com.example.util.SecurityHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ApiSimulationEngine {

    val availableEndpoints = listOf(
        ApiEndpointDef(
            id = "ep_emp_list",
            method = "GET",
            path = "/api/v1/employees",
            title = "Master Data Karyawan",
            description = "Mengambil seluruh daftar karyawan terdaftar beserta status device binding dan saldo cuti.",
            category = "Karyawan",
            defaultPayload = ""
        ),
        ApiEndpointDef(
            id = "ep_att_today",
            method = "GET",
            path = "/api/v1/attendance/today",
            title = "Presensi Realtime Hari Ini",
            description = "Mengambil log kehadiran karyawan khusus hari berjalan dengan status on-time/terlambat.",
            category = "Absensi",
            defaultPayload = ""
        ),
        ApiEndpointDef(
            id = "ep_att_logs",
            method = "GET",
            path = "/api/v1/attendance/logs",
            title = "Seluruh Riwayat Log Absensi",
            description = "Mengambil riwayat log presensi lengkap beserta koordinat GPS dan ID perangkat.",
            category = "Absensi",
            defaultPayload = ""
        ),
        ApiEndpointDef(
            id = "ep_att_checkin",
            method = "POST",
            path = "/api/v1/attendance/checkin",
            title = "Submit Presensi Karyawan",
            description = "Merekam check-in presensi baru dengan verifikasi HMAC digital signature dan koordinat GPS.",
            category = "Absensi",
            defaultPayload = """{
  "employeeNik": "OTSM23E27A001",
  "tipe": "HADIR",
  "lokasi": "Kantor Pusat Smart HC",
  "deviceId": "HP-Ari-Primary",
  "signatureHmac": "auto-generated-signature"
}"""
        ),
        ApiEndpointDef(
            id = "ep_app_list",
            method = "GET",
            path = "/api/v1/approvals/pending",
            title = "Daftar Tiket Pengajuan Pending",
            description = "Mengambil seluruh tiket approval cuti, lembur, dan reset HP yang menunggu persetujuan HRD.",
            category = "Approval",
            defaultPayload = ""
        ),
        ApiEndpointDef(
            id = "ep_app_submit",
            method = "POST",
            path = "/api/v1/approvals/submit",
            title = "Kirim Pengajuan Approval Baru",
            description = "Membuat tiket pengajuan cuti, sakit, atau lembur dari karyawan.",
            category = "Approval",
            defaultPayload = """{
  "employeeNik": "OTSM23E27A001",
  "tipe": "CUTI",
  "alasan": "Keperluan keluarga di luar kota",
  "lampiranUrl": "https://vault.smarthc.internal/docs/form_cuti.pdf"
}"""
        ),
        ApiEndpointDef(
            id = "ep_sec_verify",
            method = "POST",
            path = "/api/v1/security/verify-device",
            title = "Verifikasi Hardware Attestation",
            description = "Memvalidasi tanda tangan kriptografi perangkat keras HP terhadap data master NIK karyawan.",
            category = "Sistem",
            defaultPayload = """{
  "employeeNik": "OTSM23E27A001",
  "deviceId": "HP-Ari-Primary",
  "clientNonce": "9a8f21bc4d3e",
  "timestamp": 1724370000000
}"""
        ),
        ApiEndpointDef(
            id = "ep_sys_health",
            method = "GET",
            path = "/api/v1/system/health",
            title = "System Health & Uptime Status",
            description = "Pemeriksaan kesehatan server, utilisasi memori, status maintenance, dan konektivitas database.",
            category = "Sistem",
            defaultPayload = ""
        )
    )

    fun executeApi(
        endpoint: ApiEndpointDef,
        payload: String,
        apiKey: String,
        isKeyActive: Boolean,
        employees: List<Employee>,
        attendanceLogs: List<AttendanceLog>,
        approvalRequests: List<ApprovalRequest>,
        isMaintenanceMode: Boolean,
        officeName: String,
        policy: SecurityPolicyConfig
    ): ApiResponseResult {
        val startTime = System.currentTimeMillis()
        val now = System.currentTimeMillis()
        val sdfIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        val timestampIso = sdfIso.format(Date(now))

        // Check 1: API Key Authorization
        if (apiKey.isBlank() || !isKeyActive) {
            val latency = (20..50).random().toLong()
            return ApiResponseResult(
                statusCode = 401,
                statusText = "Unauthorized",
                latencyMs = latency,
                headers = mapOf(
                    "Content-Type" to "application/json; charset=utf-8",
                    "X-RateLimit-Limit" to "${policy.apiRateLimitRpm}",
                    "X-RateLimit-Remaining" to "0",
                    "X-Security-Policy" to "HMAC-SHA256"
                ),
                jsonBody = """{
  "error": {
    "code": "UNAUTHORIZED_API_KEY",
    "message": "Kunci API (${apiKey.take(12)}...) tidak valid, dinonaktifkan, atau kedaluwarsa.",
    "timestamp": "$timestampIso",
    "resolution": "Periksa tab Kelola API Keys di IT Control Center untuk mengaktifkan kembali."
  }
}""",
                isSuccess = false
            )
        }

        // Check 2: Maintenance Mode Check (if non-GET or system)
        if (isMaintenanceMode && endpoint.method == "POST") {
            val latency = (30..60).random().toLong()
            return ApiResponseResult(
                statusCode = 503,
                statusText = "Service Unavailable (Maintenance Mode)",
                latencyMs = latency,
                headers = mapOf(
                    "Content-Type" to "application/json",
                    "Retry-After" to "300"
                ),
                jsonBody = """{
  "error": {
    "code": "MAINTENANCE_IN_PROGRESS",
    "message": "Sistem Smart HC sedang dalam pemeliharaan terjadwal oleh IT Administrator.",
    "timestamp": "$timestampIso"
  }
}""",
                isSuccess = false
            )
        }

        // Process request according to path
        val hmacSign = SecurityHelper.generateHmacSha256(endpoint.path + timestampIso)
        val latency = (35..110).random().toLong()

        val jsonResponse = when (endpoint.path) {
            "/api/v1/employees" -> {
                val empJsonList = employees.joinToString(",\n") { emp ->
                    """    {
      "nik": "${emp.nik}",
      "nama": "${emp.nama}",
      "jabatan": "${emp.jabatan}",
      "departemen": "${emp.departemen}",
      "deviceId": "${emp.device}",
      "sisaCuti": ${emp.sisaCuti},
      "email": "${emp.email}",
      "statusRequestReset": ${emp.statusRequestReset}
    }"""
                }
                """{
  "status": "success",
  "statusCode": 200,
  "timestamp": "$timestampIso",
  "meta": {
    "totalRecords": ${employees.size},
    "version": "v1.4.0",
    "signature": "$hmacSign"
  },
  "data": [
$empJsonList
  ]
}"""
            }

            "/api/v1/attendance/today" -> {
                val todayLogs = attendanceLogs.take(10)
                val logsJson = todayLogs.joinToString(",\n") { log ->
                    """    {
      "id": ${log.id},
      "employeeNik": "${log.employeeNik}",
      "nama": "${log.employeeNama}",
      "type": "${log.type}",
      "timeString": "${log.timeString}",
      "latitude": ${log.latitude},
      "longitude": ${log.longitude},
      "accuracy": "${log.accuracy}",
      "statusVerifikasi": "VERIFIED_HARDWARE_HMAC"
    }"""
                }
                """{
  "status": "success",
  "statusCode": 200,
  "timestamp": "$timestampIso",
  "meta": {
    "officeLocation": "$officeName",
    "totalCheckInsToday": ${todayLogs.size},
    "signature": "$hmacSign"
  },
  "data": [
$logsJson
  ]
}"""
            }

            "/api/v1/attendance/logs" -> {
                val allLogsJson = attendanceLogs.take(20).joinToString(",\n") { log ->
                    """    {
      "id": ${log.id},
      "employeeNik": "${log.employeeNik}",
      "nama": "${log.employeeNama}",
      "type": "${log.type}",
      "timestamp": ${log.timestamp},
      "timeString": "${log.timeString}",
      "latitude": ${log.latitude},
      "longitude": ${log.longitude}
    }"""
                }
                """{
  "status": "success",
  "statusCode": 200,
  "timestamp": "$timestampIso",
  "meta": {
    "totalLogsInDb": ${attendanceLogs.size},
    "limit": 20,
    "signature": "$hmacSign"
  },
  "data": [
$allLogsJson
  ]
}"""
            }

            "/api/v1/attendance/checkin" -> {
                """{
  "status": "success",
  "statusCode": 201,
  "timestamp": "$timestampIso",
  "message": "Presensi berhasil divalidasi dan disimpan ke database lokal terenkripsi.",
  "data": {
    "attendanceId": ${System.currentTimeMillis() % 100000},
    "employeeNik": "OTSM23E27A001",
    "nama": "Ari Rurianto",
    "tipe": "HADIR",
    "statusKetepatan": "TEPAT_WAKTU",
    "geofenceStatus": "INSIDE_OFFICE_RADIUS (OK)",
    "antiMockGpsCheck": "PASSED (No Mock Provider)",
    "deviceBindingCheck": "PASSED (HP-Ari-Primary Match)",
    "hmacSignature": "$hmacSign"
  }
}"""
            }

            "/api/v1/approvals/pending" -> {
                val pendingList = approvalRequests.filter { it.status.equals("pending", ignoreCase = true) }
                val pendingJson = pendingList.joinToString(",\n") { req ->
                    """    {
      "id": ${req.id},
      "employeeNik": "${req.employeeNik}",
      "nama": "${req.employeeNama}",
      "type": "${req.type}",
      "reason": "${req.reason.replace("\"", "\\\"")}",
      "status": "${req.status}",
      "timeString": "${req.timeString}"
    }"""
                }
                """{
  "status": "success",
  "statusCode": 200,
  "timestamp": "$timestampIso",
  "meta": {
    "pendingCount": ${pendingList.size},
    "totalTickets": ${approvalRequests.size}
  },
  "data": [
$pendingJson
  ]
}"""
            }

            "/api/v1/approvals/submit" -> {
                """{
  "status": "success",
  "statusCode": 201,
  "timestamp": "$timestampIso",
  "message": "Tiket pengajuan berhasil dibuat dan diteruskan ke antrean approval HRD.",
  "data": {
    "ticketId": "REQ-${System.currentTimeMillis() % 10000}",
    "status": "PENDING_HRD_REVIEW",
    "estimatedSla": "1x24 Jam Kerja",
    "securityAuditHash": "$hmacSign"
  }
}"""
            }

            "/api/v1/security/verify-device" -> {
                """{
  "status": "success",
  "statusCode": 200,
  "timestamp": "$timestampIso",
  "verification": {
    "isAuthorized": true,
    "hardwareMatch": true,
    "registeredDevice": "HP-Ari-Primary",
    "clientDevice": "HP-Ari-Primary",
    "cryptographicNonceValid": true,
    "tamperFlag": false,
    "mockLocationFlag": false,
    "securityLevel": "LEVEL_4_ENTERPRISE_HMAC"
  }
}"""
            }

            "/api/v1/system/health" -> {
                val runtime = Runtime.getRuntime()
                val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                val maxMem = runtime.maxMemory() / (1024 * 1024)
                """{
  "status": "healthy",
  "statusCode": 200,
  "timestamp": "$timestampIso",
  "system": {
    "service": "Smart HC Enterprise REST Gateway",
    "version": "v1.4.2-secure",
    "maintenanceMode": $isMaintenanceMode,
    "database": {
      "engine": "Room SQLite Embedded",
      "status": "CONNECTED",
      "records": {
        "employees": ${employees.size},
        "attendanceLogs": ${attendanceLogs.size},
        "approvalRequests": ${approvalRequests.size}
      }
    },
    "security": {
      "antiMockGps": ${policy.antiMockGpsEnabled},
      "antiRoot": ${policy.rootDetectionEnabled},
      "hmacSigning": ${policy.hmacSigningRequired},
      "deviceBinding": ${policy.deviceBindingStrict}
    },
    "memory": {
      "heapUsedMb": $usedMem,
      "heapMaxMb": $maxMem,
      "status": "OPTIMAL"
    }
  }
}"""
            }

            else -> {
                """{
  "status": "error",
  "statusCode": 404,
  "timestamp": "$timestampIso",
  "message": "Endpoint '${endpoint.path}' tidak ditemukan."
}"""
            }
        }

        return ApiResponseResult(
            statusCode = if (endpoint.method == "POST") 201 else 200,
            statusText = if (endpoint.method == "POST") "Created" else "OK",
            latencyMs = latency,
            headers = mapOf(
                "Content-Type" to "application/json; charset=utf-8",
                "X-RateLimit-Limit" to "${policy.apiRateLimitRpm}",
                "X-RateLimit-Remaining" to "${policy.apiRateLimitRpm - 1}",
                "X-Signature-HMAC" to hmacSign,
                "X-Response-Time" to "${latency}ms",
                "X-Powered-By" to "Smart-HC-Enterprise-Engine"
            ),
            jsonBody = jsonResponse,
            isSuccess = true,
            signatureHmac = hmacSign
        )
    }
}
