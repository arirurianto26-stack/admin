package com.example.ui.it

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalRequest
import com.example.data.model.AttendanceLog
import com.example.data.model.Employee
import com.example.data.model.SecurityPolicyConfig
import com.example.util.AttendanceExportHelper
import com.example.util.ExportResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PwaSyncTransaction(
    val id: String,
    val timestamp: String,
    val action: String,
    val endpoint: String,
    val payloadPreview: String,
    val status: String,
    val latencyMs: Int,
    val isSuccess: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PwaSyncModule(
    employees: List<Employee>,
    attendanceLogs: List<AttendanceLog>,
    approvalRequests: List<ApprovalRequest>,
    isMaintenanceMode: Boolean,
    officeName: String,
    officeRadius: String,
    policy: SecurityPolicyConfig,
    onSyncAttendance: (String, String, String, Double, Double, String) -> Unit,
    onSyncApproval: (String, String, String, String) -> Unit,
    onSyncDeviceStatus: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Sub-view: "SIMULATOR", "EXPORT_HTML", "LOGS"
    var pwaTab by remember { mutableStateOf("SIMULATOR") }

    // API Config State for PWA
    var apiGatewayUrl by remember { mutableStateOf("https://api.smarthc.internal") }
    var syncApiKey by remember { mutableStateOf("sk_live_9f83a04bc8d712e690fa5b8c3d11e47a") }

    // PWA Simulator States
    var selectedEmployeeNik by remember { mutableStateOf(employees.firstOrNull()?.nik ?: "OTSM23E27A001") }
    val currentEmp = employees.firstOrNull { it.nik == selectedEmployeeNik } ?: employees.firstOrNull() ?: Employee(nama = "Ari Rurianto", nik = "OTSM23E27A001", device = "HP-Ari-Primary")
    
    var simSelectedDevice by remember { mutableStateOf(currentEmp.device) }
    var simActiveModule by remember { mutableStateOf<String?>(null) } // "leave", "attendance", "overtime", "slip"
    
    // GPS & Attendance states in PWA
    var pwaGpsStatus by remember { mutableStateOf("IDLE") } // "IDLE", "SCANNING", "READY"
    var pwaAttendanceResultMsg by remember { mutableStateOf<String?>(null) }
    
    // Leave form states
    var pwaLeaveType by remember { mutableStateOf("Cuti Tahunan") }
    var pwaLeaveReason by remember { mutableStateOf("") }
    var pwaLeaveResultMsg by remember { mutableStateOf<String?>(null) }
    
    // Overtime form states
    var pwaOtDuration by remember { mutableStateOf("2 Jam (17:00 - 19:00)") }
    var pwaOtReason by remember { mutableStateOf("Penyelesaian Laporan Bulanan") }
    var pwaOtResultMsg by remember { mutableStateOf<String?>(null) }

    // HTML Export States
    var htmlExportResult by remember { mutableStateOf<ExportResult?>(null) }
    var htmlCopiedNotice by remember { mutableStateOf<String?>(null) }
    var showHtmlCodePreview by remember { mutableStateOf(false) }

    // Live PWA Sync Log History
    var syncTransactions by remember {
        mutableStateOf(
            listOf(
                PwaSyncTransaction(
                    id = "SYNC-9812",
                    timestamp = "08:42:15 WIB",
                    action = "INITIAL_HANDSHAKE",
                    endpoint = "GET /api/v1/system/health",
                    payloadPreview = """{"client": "PWA_HTML5_Standalone", "auth": "HMAC-SHA256"}""",
                    status = "200 OK",
                    latencyMs = 18,
                    isSuccess = true
                ),
                PwaSyncTransaction(
                    id = "SYNC-9813",
                    timestamp = "08:42:18 WIB",
                    action = "DEVICE_ATTEST",
                    endpoint = "POST /api/v1/auth/device-attest",
                    payloadPreview = """{"nik": "OTSM23E27A001", "hardwareId": "HP-Ari-Primary"}""",
                    status = "200 VERIFIED",
                    latencyMs = 24,
                    isSuccess = true
                )
            )
        )
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Banner Sinkronisasi PWA
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF0369A1), Color(0xFF0284C7), Color(0xFF075985))
                    )
                )
                .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                        Column {
                            Text(
                                text = "🌐 SINKRONISASI PWA / WEB MOBILE",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Integrasi Multi-Platform: HTML5 PWA ⇄ Android Host",
                                fontSize = 10.sp,
                                color = Color(0xFFE0F2FE)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF059669))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "🟢 LIVE SYNC",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Text(
                    text = "Aplikasi HTML PWA eksternal tersinkronisasi 100% dengan database Smart HC. Setiap absensi, pengajuan cuti, dan lembur dari web browser langsung masuk ke HRD Approval Center dan Log IT secara realtime.",
                    fontSize = 11.sp,
                    color = Color(0xFFF0F9FF),
                    lineHeight = 15.sp
                )

                // Quick Navigation Tabs for PWA
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val subTabs = listOf(
                        Triple("SIMULATOR", "📱 Simulator PWA", "pwa_subtab_sim"),
                        Triple("EXPORT_HTML", "📥 Unduh File HTML", "pwa_subtab_export"),
                        Triple("LOGS", "⚡ Log Transaksi (${syncTransactions.size})", "pwa_subtab_logs")
                    )
                    subTabs.forEach { (tabKey, label, testTagKey) ->
                        val isSelected = pwaTab == tabKey
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF0F172A) else Color.White.copy(alpha = 0.15f))
                                .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { pwaTab = tabKey }
                                .padding(vertical = 8.dp)
                                .testTag(testTagKey),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF38BDF8) else Color.White
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // SUBTAB 1: INTERACTIVE PWA LIVE SIMULATOR
        // ==========================================
        if (pwaTab == "SIMULATOR") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Live PWA Web View (Sync Terhubung)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Database: Room Connected", fontSize = 9.sp, color = Color(0xFF34D399), fontFamily = FontFamily.Monospace)
                        }
                    }

                    // PWA Phone Canvas Mockup
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(20.dp))
                            .padding(bottom = 16.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            
                            // PWA Blue Header (Exact match to HTML template)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
                                    .background(Color(0xFF38BDF8))
                                    .padding(horizontal = 16.dp, vertical = 18.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Column {
                                            Text("Selamat Datang,", fontSize = 12.sp, color = Color.White.copy(alpha = 0.9f))
                                            Text(currentEmp.nama.uppercase(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color.White.copy(alpha = 0.25f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("PWA v1.2", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.White.copy(alpha = 0.25f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text("${currentEmp.nik} • ${currentEmp.departemen}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                                    }
                                }
                            }

                            // PWA Content Body
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp)
                                    .padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Maintenance banner if active
                                if (isMaintenanceMode) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFFFEF2F2))
                                            .border(1.dp, Color(0xFFFECACA), RoundedCornerShape(8.dp))
                                            .padding(8.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text("🚧", fontSize = 16.sp)
                                            Column {
                                                Text("Sistem Sedang Maintenance", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB91C1C))
                                                Text("Aplikasi Karyawan sedang dalam perbaikan oleh Tim IT.", fontSize = 9.sp, color = Color(0xFF7F1D1D))
                                            }
                                        }
                                    }
                                }

                                // Login Device Simulation Box
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White)
                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("Simulasi Login Perangkat HP (PWA Client):", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                                        
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (simSelectedDevice == currentEmp.device) Color(0xFFE0F2FE) else Color(0xFFF1F5F9))
                                                    .border(1.dp, if (simSelectedDevice == currentEmp.device) Color(0xFF0284C7) else Color(0xFFCBD5E1), RoundedCornerShape(6.dp))
                                                    .clickable { simSelectedDevice = currentEmp.device }
                                                    .padding(6.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("📱 HP Terdaftar (${currentEmp.device})", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0369A1))
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (simSelectedDevice != currentEmp.device) Color(0xFFFEE2E2) else Color(0xFFF1F5F9))
                                                    .border(1.dp, if (simSelectedDevice != currentEmp.device) Color(0xFFDC2626) else Color(0xFFCBD5E1), RoundedCornerShape(6.dp))
                                                    .clickable { simSelectedDevice = "HP-Lain-Baru" }
                                                    .padding(6.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("⚠️ HP Lain / Baru", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB91C1C))
                                            }
                                        }

                                        val isDeviceValid = simSelectedDevice == currentEmp.device
                                        Text(
                                            text = if (isDeviceValid) "Status PWA: Login Terverifikasi di HP Terdaftar ✅" else "Status PWA: ❌ Perangkat Asing! Permintaan reset otomatis dikirim ke HRD.",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDeviceValid) Color(0xFF047857) else Color(0xFFDC2626)
                                        )
                                    }
                                }

                                // 4-Grid Menu or Dynamic Module View
                                if (simActiveModule == null) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.White)
                                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                            .padding(14.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceAround
                                        ) {
                                            val pwaMenus = listOf(
                                                Triple("leave", "✈️", "Leave"),
                                                Triple("attendance", "📅", "Attendance"),
                                                Triple("overtime", "⏰", "Overtime"),
                                                Triple("slip", "💰", "Slip")
                                            )
                                            pwaMenus.forEach { (modKey, icon, label) ->
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    modifier = Modifier
                                                        .clickable {
                                                            simActiveModule = modKey
                                                            if (modKey == "attendance") {
                                                                pwaGpsStatus = "SCANNING"
                                                                pwaAttendanceResultMsg = null
                                                                scope.launch {
                                                                    delay(1200)
                                                                    pwaGpsStatus = "READY"
                                                                }
                                                            }
                                                        }
                                                        .padding(4.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(46.dp)
                                                            .clip(CircleShape)
                                                            .background(Color(0xFFE0F2FE)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(icon, fontSize = 20.sp)
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    // DYNAMIC ACTIVE PWA MODULE
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.White)
                                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                            .padding(12.dp)
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = when (simActiveModule) {
                                                        "leave" -> "Formulir Leave & FDA (PWA)"
                                                        "attendance" -> "Absensi GPS Radius ($officeName)"
                                                        "overtime" -> "Pengajuan Lembur (PWA)"
                                                        else -> "Slip Gaji Online (PWA)"
                                                    },
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0F172A)
                                                )
                                                Button(
                                                    onClick = { simActiveModule = null },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2E8F0)),
                                                    shape = RoundedCornerShape(4.dp),
                                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Kembali", fontSize = 9.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            // Modul 1: Leave & FDA
                                            if (simActiveModule == "leave") {
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Text("Pilih Jenis Pengajuan:", fontSize = 9.sp, color = Color(0xFF64748B))
                                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                        listOf("Cuti Tahunan", "FDA (Dinas)", "Izin Sakit").forEach { lType ->
                                                            val isSel = pwaLeaveType == lType
                                                            Box(
                                                                modifier = Modifier
                                                                    .weight(1f)
                                                                    .clip(RoundedCornerShape(6.dp))
                                                                    .background(if (isSel) Color(0xFF0284C7) else Color(0xFFF1F5F9))
                                                                    .clickable { pwaLeaveType = lType }
                                                                    .padding(vertical = 4.dp),
                                                                contentAlignment = Alignment.Center
                                                            ) {
                                                                Text(lType, fontSize = 8.sp, color = if (isSel) Color.White else Color(0xFF475569), fontWeight = FontWeight.Bold)
                                                            }
                                                        }
                                                    }

                                                    Text("Keterangan / Alasan:", fontSize = 9.sp, color = Color(0xFF64748B))
                                                    OutlinedTextField(
                                                        value = pwaLeaveReason,
                                                        onValueChange = { pwaLeaveReason = it },
                                                        placeholder = { Text("Contoh: Keperluan keluarga...", fontSize = 9.sp, color = Color.Gray) },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(6.dp),
                                                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.Black, fontSize = 10.sp),
                                                        colors = OutlinedTextFieldDefaults.colors(
                                                            focusedBorderColor = Color(0xFF0284C7),
                                                            unfocusedBorderColor = Color(0xFFCBD5E1)
                                                        )
                                                    )

                                                    Button(
                                                        onClick = {
                                                            if (pwaLeaveReason.isNotBlank()) {
                                                                onSyncApproval(currentEmp.nik, currentEmp.nama, pwaLeaveType, pwaLeaveReason)
                                                                
                                                                val newTx = PwaSyncTransaction(
                                                                    id = "SYNC-${(1000..9999).random()}",
                                                                    timestamp = SimpleDateFormat("HH:mm:ss 'WIB'", Locale.getDefault()).format(Date()),
                                                                    action = "SUBMIT_LEAVE",
                                                                    endpoint = "POST /api/v1/approvals/submit",
                                                                    payloadPreview = """{"nik": "${currentEmp.nik}", "type": "$pwaLeaveType", "reason": "$pwaLeaveReason"}""",
                                                                    status = "201 CREATED",
                                                                    latencyMs = (12..35).random(),
                                                                    isSuccess = true
                                                                )
                                                                syncTransactions = listOf(newTx) + syncTransactions

                                                                pwaLeaveResultMsg = "✅ Berhasil disinkronkan ke HRD Approval Center!"
                                                                pwaLeaveReason = ""
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                                        shape = RoundedCornerShape(6.dp),
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag("btn_pwa_submit_leave")
                                                    ) {
                                                        Text("Kirim Pengajuan (Auto-Sync DB)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }

                                                    pwaLeaveResultMsg?.let {
                                                        Text(it, color = Color(0xFF059669), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            // Modul 2: Attendance GPS
                                            if (simActiveModule == "attendance") {
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    if (pwaGpsStatus == "SCANNING") {
                                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF0284C7), strokeWidth = 2.dp)
                                                        Text("🔄 Sedang mendeteksi sinyal satelit GPS...", fontSize = 10.sp, color = Color(0xFFD97706), fontWeight = FontWeight.Bold)
                                                        Text("Mencari titik koordinat akurat di dalam radius kantor...", fontSize = 8.sp, color = Color(0xFF64748B))
                                                    } else {
                                                        Text("✅ Lokasi Akurat Dalam Radius $officeName!", fontSize = 10.sp, color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                                                        Text("Lat: -6.200000, Long: 106.816666 (Akurasi ±3 meter)", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                                        
                                                        Box(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .clip(RoundedCornerShape(6.dp))
                                                                .background(Color(0xFF22C55E))
                                                                .padding(vertical = 6.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text("🔓 Gate Time Terbuka", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                        }

                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Button(
                                                                onClick = {
                                                                    onSyncAttendance(currentEmp.nik, currentEmp.nama, "Check In", -6.200000, 106.816666, currentEmp.device)
                                                                    
                                                                    val newTx = PwaSyncTransaction(
                                                                        id = "SYNC-${(1000..9999).random()}",
                                                                        timestamp = SimpleDateFormat("HH:mm:ss 'WIB'", Locale.getDefault()).format(Date()),
                                                                        action = "CHECK_IN",
                                                                        endpoint = "POST /api/v1/attendance/checkin",
                                                                        payloadPreview = """{"nik": "${currentEmp.nik}", "type": "Check In", "deviceId": "${currentEmp.device}"}""",
                                                                        status = "200 OK",
                                                                        latencyMs = (15..40).random(),
                                                                        isSuccess = true
                                                                    )
                                                                    syncTransactions = listOf(newTx) + syncTransactions

                                                                    pwaAttendanceResultMsg = "✅ Check In tersinkron ke Server Smart HC!"
                                                                },
                                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                                                shape = RoundedCornerShape(6.dp),
                                                                modifier = Modifier
                                                                    .weight(1f)
                                                                    .testTag("btn_pwa_checkin")
                                                            ) {
                                                                Text("📥 Check In", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                            }

                                                            Button(
                                                                onClick = {
                                                                    onSyncAttendance(currentEmp.nik, currentEmp.nama, "Check Out", -6.200000, 106.816666, currentEmp.device)
                                                                    
                                                                    val newTx = PwaSyncTransaction(
                                                                        id = "SYNC-${(1000..9999).random()}",
                                                                        timestamp = SimpleDateFormat("HH:mm:ss 'WIB'", Locale.getDefault()).format(Date()),
                                                                        action = "CHECK_OUT",
                                                                        endpoint = "POST /api/v1/attendance/checkin",
                                                                        payloadPreview = """{"nik": "${currentEmp.nik}", "type": "Check Out", "deviceId": "${currentEmp.device}"}""",
                                                                        status = "200 OK",
                                                                        latencyMs = (15..40).random(),
                                                                        isSuccess = true
                                                                    )
                                                                    syncTransactions = listOf(newTx) + syncTransactions

                                                                    pwaAttendanceResultMsg = "✅ Check Out tersinkron ke Server Smart HC!"
                                                                },
                                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF43F5E)),
                                                                shape = RoundedCornerShape(6.dp),
                                                                modifier = Modifier
                                                                    .weight(1f)
                                                                    .testTag("btn_pwa_checkout")
                                                            ) {
                                                                Text("📤 Check Out", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                            }
                                                        }
                                                    }

                                                    pwaAttendanceResultMsg?.let {
                                                        Text(it, color = Color(0xFF059669), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            // Modul 3: Overtime
                                            if (simActiveModule == "overtime") {
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Text("Durasi Lembur:", fontSize = 9.sp, color = Color(0xFF64748B))
                                                    OutlinedTextField(
                                                        value = pwaOtDuration,
                                                        onValueChange = { pwaOtDuration = it },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(6.dp),
                                                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.Black, fontSize = 10.sp)
                                                    )

                                                    Text("Deskripsi Tugas Lembur:", fontSize = 9.sp, color = Color(0xFF64748B))
                                                    OutlinedTextField(
                                                        value = pwaOtReason,
                                                        onValueChange = { pwaOtReason = it },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(6.dp),
                                                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.Black, fontSize = 10.sp)
                                                    )

                                                    Button(
                                                        onClick = {
                                                            if (pwaOtReason.isNotBlank()) {
                                                                onSyncApproval(currentEmp.nik, currentEmp.nama, "Lembur ($pwaOtDuration)", pwaOtReason)
                                                                
                                                                val newTx = PwaSyncTransaction(
                                                                    id = "SYNC-${(1000..9999).random()}",
                                                                    timestamp = SimpleDateFormat("HH:mm:ss 'WIB'", Locale.getDefault()).format(Date()),
                                                                    action = "SUBMIT_OVERTIME",
                                                                    endpoint = "POST /api/v1/approvals/submit",
                                                                    payloadPreview = """{"nik": "${currentEmp.nik}", "duration": "$pwaOtDuration", "task": "$pwaOtReason"}""",
                                                                    status = "201 CREATED",
                                                                    latencyMs = (16..38).random(),
                                                                    isSuccess = true
                                                                )
                                                                syncTransactions = listOf(newTx) + syncTransactions

                                                                pwaOtResultMsg = "✅ Pengajuan lembur terkirim ke HRD!"
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                                        shape = RoundedCornerShape(6.dp),
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag("btn_pwa_submit_overtime")
                                                    ) {
                                                        Text("Ajukan Lembur (Auto-Sync)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }

                                                    pwaOtResultMsg?.let {
                                                        Text(it, color = Color(0xFF059669), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            // Modul 4: Slip
                                            if (simActiveModule == "slip") {
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Text("Email Terdaftar:", fontSize = 9.sp, color = Color(0xFF64748B))
                                                    OutlinedTextField(
                                                        value = currentEmp.email,
                                                        onValueChange = {},
                                                        readOnly = true,
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(6.dp),
                                                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.Black, fontSize = 10.sp)
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(Color(0xFFECFDF5))
                                                            .padding(8.dp)
                                                    ) {
                                                        Text("✅ Tautan slip gaji terkirim via server Smart HC ke ${currentEmp.email}", fontSize = 9.sp, color = Color(0xFF065F46))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // SUBTAB 2: EXPORT & DOWNLOAD STANDALONE HTML
        // ==========================================
        if (pwaTab == "EXPORT_HTML") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ekspor File HTML PWA Mandiri",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    Text(
                        text = "Unduh atau salin file HTML lengkap yang sudah terintegrasi dengan REST API Smart HC, konfigurasi PWA Web App manifest, dan enkripsi payload.",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        lineHeight = 15.sp
                    )

                    // Target API Gateway Configuration
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Target API Gateway URL:", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        OutlinedTextField(
                            value = apiGatewayUrl,
                            onValueChange = { apiGatewayUrl = it },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF334155)
                            )
                        )

                        Text("Authorization Bearer API Key:", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        OutlinedTextField(
                            value = syncApiKey,
                            onValueChange = { syncApiKey = it },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFFA7F3D0), fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF334155)
                            )
                        )
                    }

                    // Action Buttons (Download, Copy, Share)
                    val generatedHtml = remember(apiGatewayUrl, syncApiKey, officeName, officeRadius) {
                        AttendanceExportHelper.generateSyncedPwaHtml(
                            apiUrl = apiGatewayUrl,
                            apiKey = syncApiKey,
                            officeName = officeName,
                            officeRadius = officeRadius
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val res = AttendanceExportHelper.saveExportFile(
                                    context = context,
                                    prefix = "smart_hc_karyawan_synced",
                                    extension = "html",
                                    content = generatedHtml,
                                    recordCount = 1
                                )
                                htmlExportResult = res
                                htmlCopiedNotice = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("btn_download_pwa_html")
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Unduh File HTML", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                AttendanceExportHelper.shareExportContent(
                                    context = context,
                                    title = "Smart HC - Karyawan PWA Synced HTML",
                                    content = generatedHtml
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(0.9f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bagikan", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val copied = AttendanceExportHelper.copyToClipboard(context, generatedHtml, "Smart HC PWA HTML")
                                if (copied) {
                                    htmlCopiedNotice = "📋 Kode HTML PWA Tersalin ke Clipboard!"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(0.8f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Salin", fontSize = 11.sp, color = Color(0xFF38BDF8))
                        }
                    }

                    htmlCopiedNotice?.let { msg ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0C4A6E))
                                .padding(8.dp)
                        ) {
                            Text(msg, color = Color(0xFF38BDF8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    htmlExportResult?.let { res ->
                        if (res.isSuccess) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF064E3B))
                                    .border(1.dp, Color(0xFF059669), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF34D399), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "File HTML Siap Dijalankan di Browser / HP!",
                                            color = Color(0xFF34D399),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = "📄 File: ${res.fileName}\n💾 Size: ${res.formattedSize}\n📁 Path: ${res.fileAbsolutePath}",
                                        color = Color(0xFFA7F3D0),
                                        fontSize = 10.sp,
                                        lineHeight = 14.sp,
                                        fontFamily = FontFamily.Monospace
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(
                                            onClick = { showHtmlCodePreview = !showHtmlCodePreview },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text(if (showHtmlCodePreview) "Tutup Kode" else "Lihat Kode HTML", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            if (showHtmlCodePreview) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF020617))
                                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(6.dp))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = res.content.lines().take(15).joinToString("\n") + "\n... (${res.content.lines().size - 15} baris lainnya)",
                                        color = Color(0xFF38BDF8),
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // SUBTAB 3: REALTIME PWA SYNC LOGS
        // ==========================================
        if (pwaTab == "LOGS") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sync, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Riwayat Sinkronisasi Masuk (PWA Stream)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }

                        Button(
                            onClick = { syncTransactions = emptyList() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bersihkan", fontSize = 9.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    if (syncTransactions.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Belum ada transaksi sinkronisasi dari PWA.", color = Color(0xFF64748B), fontSize = 10.sp)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            syncTransactions.forEach { tx ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF1E293B))
                                        .border(1.dp, Color(0xFF059669).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .padding(10.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(Color(0xFF059669))
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                ) {
                                                    Text(tx.status, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                                }
                                                Text(tx.endpoint, color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                            }
                                            Text("${tx.latencyMs}ms • ${tx.timestamp}", color = Color(0xFF94A3B8), fontSize = 8.sp)
                                        }

                                        Text(
                                            text = tx.payloadPreview,
                                            color = Color(0xFFA5B4FC),
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
