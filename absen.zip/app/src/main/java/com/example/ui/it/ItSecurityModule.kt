package com.example.ui.it

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.GppMaybe
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SecurityAuditResult
import com.example.data.model.SecurityIncident
import com.example.data.model.SecurityPolicyConfig
import com.example.util.AttendanceExportHelper
import com.example.util.SecurityHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ItSecurityModule(
    policy: SecurityPolicyConfig,
    onUpdatePolicy: (SecurityPolicyConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isScanning by remember { mutableStateOf(false) }
    var scanProgress by remember { mutableStateOf(0f) }
    var scanStepText by remember { mutableStateOf("") }
    var auditResult by remember { mutableStateOf(SecurityHelper.runFullSecurityDiagnostic(policy)) }

    // Incident Logs State
    var incidentLogs by remember {
        mutableStateOf(
            listOf(
                SecurityIncident(
                    id = "inc_1",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 3,
                    timeFormatted = "Hari ini • 08:35:12 WIB",
                    eventType = "MOCK_GPS_BLOCKED",
                    severity = "DANGER",
                    details = "Percobaan manipulasi Fake GPS (Mock Location Provider) diblokir dari perangkat tidak terdaftar.",
                    sourceIp = "182.1.20.44",
                    deviceId = "HP-Simulasi-Root"
                ),
                SecurityIncident(
                    id = "inc_2",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 18,
                    timeFormatted = "Hari ini • 08:20:05 WIB",
                    eventType = "DEVICE_MISMATCH",
                    severity = "WARNING",
                    details = "Upaya login NIK OTSM23E27A001 dari hardware ID tidak terdaftar (HP-Lain). Akses dibatasi ke Mode Reset.",
                    sourceIp = "192.168.1.109",
                    deviceId = "HP-Lain-Tidak-Terdaftar"
                ),
                SecurityIncident(
                    id = "inc_3",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                    timeFormatted = "Hari ini • 07:55:00 WIB",
                    eventType = "HMAC_VERIFIED",
                    severity = "INFO",
                    details = "Verifikasi HMAC-SHA256 transaksi presensi valid & tersimpan ke enkripsi lokal.",
                    sourceIp = "192.168.1.104",
                    deviceId = "HP-Ari-Primary"
                ),
                SecurityIncident(
                    id = "inc_4",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
                    timeFormatted = "Hari ini • 06:40:22 WIB",
                    eventType = "ROOT_CHECK",
                    severity = "INFO",
                    details = "Audit integritas lingkungan client: Bersih dari root su binary & Magisk hook.",
                    sourceIp = "127.0.0.1",
                    deviceId = "Device-Integrity-Agent"
                )
            )
        )
    }

    var selectedSeverityFilter by remember { mutableStateOf("SEMUA") } // "SEMUA", "DANGER", "WARNING", "INFO"

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Security Header & Hardening Shield Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF0F172A))
                    )
                )
                .border(1.dp, Color(0xFF4F46E5), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF4338CA)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFFA5B4FC), modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text(
                                text = "🛡️ SISTEM KEAMANAN & ANTI-HACK",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE0E7FF)
                            )
                            Text(
                                text = "Level 4 Enterprise Hardened Shield",
                                fontSize = 10.sp,
                                color = Color(0xFF818CF8)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF065F46))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "SCORE: ${auditResult.score}/100",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF34D399)
                        )
                    }
                }

                Text(
                    text = "Sistem keamanan multi-lapis aktif melindungi aplikasi dari pemalsuan lokasi GPS (Tuyul), serangan Man-in-the-Middle (MITM), manipulasi hardware ID, dan perangkat yang dimodifikasi (Root/Magisk).",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 15.sp
                )

                // Quick Security Vector Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val badges = listOf(
                        "🛰️ Anti-Mock GPS",
                        "🔐 HMAC SHA256",
                        "📱 Binding 1:1",
                        "🚫 Anti-Root"
                    )
                    badges.forEach { b ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = b, fontSize = 8.sp, color = Color(0xFFC7D2FE), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // 2. One-Tap Security Diagnostic Scanner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Radar, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🔍 Audit & Scanner Keamanan Sistem",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Button(
                        onClick = {
                            isScanning = true
                            scanProgress = 0f
                            scope.launch {
                                val steps = listOf(
                                    "Memeriksa integritas binary OS & status Root...",
                                    "Memvalidasi proteksi Mock Provider & Geofence GPS...",
                                    "Memeriksa kunci kriptografi HMAC-SHA256...",
                                    "Menguji otentikasi Hardware ID Device Binding...",
                                    "Memverifikasi modul Rate Limiter & Anti Brute-Force...",
                                    "Audit selesai. Menghitung Security Posture Score..."
                                )
                                for (i in steps.indices) {
                                    scanStepText = steps[i]
                                    scanProgress = (i + 1).toFloat() / steps.size
                                    delay(200)
                                }
                                auditResult = SecurityHelper.runFullSecurityDiagnostic(policy)
                                isScanning = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isScanning,
                        modifier = Modifier.testTag("btn_it_run_security_scan")
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scanning...", fontSize = 10.sp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Jalankan Audit", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (isScanning) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(scanStepText, color = Color(0xFFA5B4FC), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        LinearProgressIndicator(
                            progress = { scanProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFF6366F1),
                            trackColor = Color(0xFF1E293B),
                        )
                    }
                }

                // Audit Results Checklist
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    auditResult.checkDetails.forEach { check ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, if (check.isPassed) Color(0xFF059669) else Color(0xFFDC2626), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = if (check.isPassed) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (check.isPassed) Color(0xFF34D399) else Color(0xFFF87171),
                                    modifier = Modifier.size(18.dp)
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = check.title,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "${check.category} (+${check.scoreImpact} pts)",
                                            fontSize = 9.sp,
                                            color = Color(0xFF38BDF8)
                                        )
                                    }
                                    Text(
                                        text = check.details,
                                        fontSize = 10.sp,
                                        color = Color(0xFF94A3B8),
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Security Policy & Anti-Hack Configuration Toggles
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚙️ Kebijakan Keamanan & Anti-Tamper",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8)
                    )
                }

                // Policy 1: Anti-Mock GPS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Anti-Tuyul GPS (Mock Location Provider Block)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Deteksi dan blokir aplikasi fake GPS/joystick lokasi saat presensi.", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }
                    Switch(
                        checked = policy.antiMockGpsEnabled,
                        onCheckedChange = {
                            val updated = policy.copy(antiMockGpsEnabled = it)
                            onUpdatePolicy(updated)
                            auditResult = SecurityHelper.runFullSecurityDiagnostic(updated)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669),
                            uncheckedThumbColor = Color(0xFF94A3B8),
                            uncheckedTrackColor = Color(0xFF334155)
                        )
                    )
                }

                // Policy 2: Strict Hardware Device Binding
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Strict Hardware ID Device Binding (1:1)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Wajibkan presensi hanya dari HP terdaftar. Tolak pergantian HP tanpa izin HRD.", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }
                    Switch(
                        checked = policy.deviceBindingStrict,
                        onCheckedChange = {
                            val updated = policy.copy(deviceBindingStrict = it)
                            onUpdatePolicy(updated)
                            auditResult = SecurityHelper.runFullSecurityDiagnostic(updated)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669),
                            uncheckedThumbColor = Color(0xFF94A3B8),
                            uncheckedTrackColor = Color(0xFF334155)
                        )
                    )
                }

                // Policy 3: HMAC-SHA256 Request Signing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Wajibkan Tanda Tangan Kriptografi HMAC-SHA256", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Setiap payload request di-sign dengan secret salt mencegah serangan replay MITM.", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }
                    Switch(
                        checked = policy.hmacSigningRequired,
                        onCheckedChange = {
                            val updated = policy.copy(hmacSigningRequired = it)
                            onUpdatePolicy(updated)
                            auditResult = SecurityHelper.runFullSecurityDiagnostic(updated)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669),
                            uncheckedThumbColor = Color(0xFF94A3B8),
                            uncheckedTrackColor = Color(0xFF334155)
                        )
                    )
                }

                // Policy 4: Anti-Root / Jailbreak Detection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Blokir Perangkat Rooted / Magisk Hook", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Pindai su binaries dan hooking framework untuk mencegah reverse engineering.", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }
                    Switch(
                        checked = policy.rootDetectionEnabled,
                        onCheckedChange = {
                            val updated = policy.copy(rootDetectionEnabled = it)
                            onUpdatePolicy(updated)
                            auditResult = SecurityHelper.runFullSecurityDiagnostic(updated)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669),
                            uncheckedThumbColor = Color(0xFF94A3B8),
                            uncheckedTrackColor = Color(0xFF334155)
                        )
                    )
                }

                // Policy 5: Anti Brute Force
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Proteksi Brute-Force & Rate Limiting", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Kunci otomatis jika 5x berturut-turut gagal otentikasi hardware atau PIN.", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }
                    Switch(
                        checked = policy.bruteForceProtection,
                        onCheckedChange = {
                            val updated = policy.copy(bruteForceProtection = it)
                            onUpdatePolicy(updated)
                            auditResult = SecurityHelper.runFullSecurityDiagnostic(updated)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669),
                            uncheckedThumbColor = Color(0xFF94A3B8),
                            uncheckedTrackColor = Color(0xFF334155)
                        )
                    )
                }
            }
        }

        // 4. Live Cyber Threat & Security Incident Log
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🚨 Log Insiden & Audit Ancaman Cyber",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Button(
                        onClick = { incidentLogs = emptyList() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bersihkan", fontSize = 9.sp, color = Color(0xFF94A3B8))
                    }
                }

                // Filter Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("SEMUA", "DANGER", "WARNING", "INFO").forEach { sev ->
                        val isSelected = selectedSeverityFilter == sev
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF1E293B))
                                .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155), RoundedCornerShape(6.dp))
                                .clickable { selectedSeverityFilter = sev }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = sev,
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                val filteredIncidents = if (selectedSeverityFilter == "SEMUA") incidentLogs else incidentLogs.filter { it.severity == selectedSeverityFilter }

                if (filteredIncidents.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Tidak ada log insiden keamanan tercatat.", color = Color(0xFF64748B), fontSize = 10.sp)
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        filteredIncidents.forEach { inc ->
                            val sevColor = when (inc.severity) {
                                "DANGER" -> Color(0xFFDC2626)
                                "WARNING" -> Color(0xFFD97706)
                                else -> Color(0xFF059669)
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E293B))
                                    .border(1.dp, sevColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(sevColor)
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(inc.severity, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Text(inc.eventType, color = Color(0xFFE2E8F0), fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                        Text(inc.timeFormatted, color = Color(0xFF94A3B8), fontSize = 8.sp)
                                    }

                                    Text(inc.details, color = Color(0xFFCBD5E1), fontSize = 9.sp, lineHeight = 13.sp)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Source: ${inc.sourceIp}", color = Color(0xFF64748B), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                        Text("Device: ${inc.deviceId}", color = Color(0xFF64748B), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
