package com.example.ui.it

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.ApiSimulationEngine
import com.example.data.model.ApiEndpointDef
import com.example.data.model.ApiKeyInfo
import com.example.data.model.ApiResponseResult
import com.example.data.model.ApprovalRequest
import com.example.data.model.AttendanceLog
import com.example.data.model.Employee
import com.example.data.model.SecurityPolicyConfig
import com.example.util.AttendanceExportHelper
import com.example.util.SecurityHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItApiModule(
    employees: List<Employee>,
    attendanceLogs: List<AttendanceLog>,
    approvalRequests: List<ApprovalRequest>,
    isMaintenanceMode: Boolean,
    officeName: String,
    policy: SecurityPolicyConfig,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Sub-tab selector in API Module
    var apiSection by remember { mutableStateOf("EXPLORER") } // "EXPLORER", "KEYS", "WEBHOOK"

    // REST Explorer States
    var selectedEndpoint by remember { mutableStateOf(ApiSimulationEngine.availableEndpoints[0]) }
    var endpointMenuExpanded by remember { mutableStateOf(false) }
    var requestPayload by remember(selectedEndpoint) { mutableStateOf(selectedEndpoint.defaultPayload) }
    var isExecutingApi by remember { mutableStateOf(false) }
    var lastApiResponse by remember { mutableStateOf<ApiResponseResult?>(null) }
    var copyAlertMessage by remember { mutableStateOf<String?>(null) }

    // API Key States
    var apiKeysList by remember {
        mutableStateOf(
            listOf(
                ApiKeyInfo(
                    id = "key_1",
                    name = "HRIS ERP Production Key",
                    key = "sk_live_9f83a04bc8d712e690fa5b8c3d11e47a",
                    role = "ERP Sync (Full-Access)",
                    createdDate = "01 Jan 2026",
                    lastUsed = "Hari ini • 08:14 WIB",
                    isActive = true,
                    rateLimitRpm = 120
                ),
                ApiKeyInfo(
                    id = "key_2",
                    name = "Payroll Engine Microservice",
                    key = "sk_live_21bc98fa47d89001ee345b88c0ab2341",
                    role = "Read-Only (Rekap)",
                    createdDate = "15 Jan 2026",
                    lastUsed = "Kemarin • 18:30 WIB",
                    isActive = true,
                    rateLimitRpm = 60
                ),
                ApiKeyInfo(
                    id = "key_3",
                    name = "Mobile App Client Public Gateway",
                    key = "sk_live_77cc88bb11aa22dd33ee44ff55667788",
                    role = "Mobile Presensi",
                    createdDate = "20 Feb 2026",
                    lastUsed = "Baru saja",
                    isActive = true,
                    rateLimitRpm = 300
                )
            )
        )
    }
    var showNewKeyDialog by remember { mutableStateOf(false) }
    var newKeyNameInput by remember { mutableStateOf("") }
    var newKeyRoleInput by remember { mutableStateOf("Full-Access") }
    var revealedKeys by remember { mutableStateOf(setOf<String>()) }

    // Webhook States
    var webhookUrl by remember { mutableStateOf("https://integrasi-erp.perusahaan.co.id/api/v1/webhook/attendance") }
    var isWebhookAttendanceChecked by remember { mutableStateOf(true) }
    var isWebhookLeaveChecked by remember { mutableStateOf(true) }
    var isWebhookSecurityChecked by remember { mutableStateOf(true) }
    var isTestingWebhook by remember { mutableStateOf(false) }
    var webhookTestResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section Title & Navigation Tabs
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(20.dp))
                Text(
                    text = "🌐 Modul REST API & Gateway Integrasi",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF8FAFC)
                )
            }
            Text(
                text = "Kelola antarmuka pemrograman aplikasi (API Gateway), uji endpoint REST live, amankan kunci autentikasi, serta konfigurasi webhook.",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8),
                lineHeight = 15.sp
            )

            // Sub-nav chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val tabs = listOf(
                    Triple("EXPLORER", "⚡ REST Playground", "tab_api_explorer"),
                    Triple("KEYS", "🔑 Kelola API Keys", "tab_api_keys"),
                    Triple("WEBHOOK", "🔗 Webhook & Sync", "tab_api_webhook")
                )
                tabs.forEach { (id, label, tag) ->
                    val isSelected = apiSection == id
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF0F172A))
                            .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155), RoundedCornerShape(8.dp))
                            .clickable { apiSection = id }
                            .padding(vertical = 8.dp)
                            .testTag(tag),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // TAB 1: REST API EXPLORER & PLAYGROUND
        if (apiSection == "EXPLORER") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "⚡ REST API Endpoint Tester & Simulator",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8)
                    )

                    // Endpoint Selector Dropdown
                    Text("Pilih API Endpoint:", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    ExposedDropdownMenuBox(
                        expanded = endpointMenuExpanded,
                        onExpandedChange = { endpointMenuExpanded = !endpointMenuExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "[${selectedEndpoint.method}] ${selectedEndpoint.path} - ${selectedEndpoint.title}",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = endpointMenuExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 11.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF334155)
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = endpointMenuExpanded,
                            onDismissRequest = { endpointMenuExpanded = false }
                        ) {
                            ApiSimulationEngine.availableEndpoints.forEach { ep ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(if (ep.method == "GET") Color(0xFF065F46) else Color(0xFF1E40AF))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = ep.method,
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Text("${ep.path} (${ep.title})", fontSize = 11.sp)
                                        }
                                    },
                                    onClick = {
                                        selectedEndpoint = ep
                                        endpointMenuExpanded = false
                                        lastApiResponse = null
                                    }
                                )
                            }
                        }
                    }

                    // Endpoint Info Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val methodColor = if (selectedEndpoint.method == "GET") Color(0xFF10B981) else Color(0xFF3B82F6)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(methodColor)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = selectedEndpoint.method,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "https://api.smarthc.internal${selectedEndpoint.path}",
                                    color = Color(0xFFF1F5F9),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = selectedEndpoint.description,
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Request Payload Editor (if POST)
                    if (selectedEndpoint.method == "POST") {
                        Text("Request Body (JSON Payload):", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        OutlinedTextField(
                            value = requestPayload,
                            onValueChange = { requestPayload = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color(0xFF38BDF8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF334155)
                            )
                        )
                    }

                    // Headers Info Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Auth: Bearer sk_live_9f83... (Active) • HMAC-SHA256 Signed",
                            fontSize = 9.sp,
                            color = Color(0xFF64748B),
                            fontFamily = FontFamily.Monospace
                        )

                        Button(
                            onClick = {
                                isExecutingApi = true
                                scope.launch {
                                    delay(200) // realistic network simulation
                                    val activeKey = apiKeysList.firstOrNull { it.isActive }
                                    val keyStr = activeKey?.key ?: "sk_live_demo"
                                    val res = ApiSimulationEngine.executeApi(
                                        endpoint = selectedEndpoint,
                                        payload = requestPayload,
                                        apiKey = keyStr,
                                        isKeyActive = activeKey != null,
                                        employees = employees,
                                        attendanceLogs = attendanceLogs,
                                        approvalRequests = approvalRequests,
                                        isMaintenanceMode = isMaintenanceMode,
                                        officeName = officeName,
                                        policy = policy
                                    )
                                    lastApiResponse = res
                                    isExecutingApi = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            enabled = !isExecutingApi,
                            modifier = Modifier.testTag("btn_it_run_api")
                        ) {
                            if (isExecutingApi) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Memproses...", fontSize = 11.sp)
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Kirim Request API", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Response Section
                    lastApiResponse?.let { res ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF020617))
                                .border(1.dp, if (res.isSuccess) Color(0xFF059669) else Color(0xFFDC2626), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(if (res.statusCode in 200..299) Color(0xFF059669) else Color(0xFFDC2626))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "${res.statusCode} ${res.statusText}",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = "⏱️ ${res.latencyMs} ms",
                                            color = Color(0xFF94A3B8),
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            val copied = AttendanceExportHelper.copyToClipboard(context, res.jsonBody, "JSON API Response")
                                            if (copied) {
                                                copyAlertMessage = "📋 JSON Response disalin ke clipboard!"
                                            }
                                        },
                                        modifier = Modifier.size(26.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Salin JSON", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                    }
                                }

                                if (copyAlertMessage != null) {
                                    Text(copyAlertMessage ?: "", color = Color(0xFF34D399), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                // JSON Body Display
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF0F172A))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = res.jsonBody,
                                        color = if (res.isSuccess) Color(0xFF38BDF8) else Color(0xFFFCA5A5),
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 13.sp
                                    )
                                }

                                // Security signature footer
                                if (res.signatureHmac.isNotBlank()) {
                                    Text(
                                        text = "🔒 HMAC Signature: ${res.signatureHmac.take(32)}...",
                                        color = Color(0xFF64748B),
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: API KEY MANAGEMENT VAULT
        if (apiSection == "KEYS") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🔑 Vault & Manajemen API Keys",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }

                        Button(
                            onClick = { showNewKeyDialog = !showNewKeyDialog },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Buat Kunci Baru", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Kunci otorisasi Bearer Token untuk microservice, sistem ERP, dan client mobile presensi.",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )

                    // Form Buat Kunci Baru
                    AnimatedVisibility(visible = showNewKeyDialog) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color(0xFF0284C7), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Generate Kunci API Baru:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                
                                OutlinedTextField(
                                    value = newKeyNameInput,
                                    onValueChange = { newKeyNameInput = it },
                                    placeholder = { Text("Contoh: Integrasi SAP Payroll", fontSize = 10.sp, color = Color.Gray) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(6.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 11.sp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFF38BDF8),
                                        unfocusedBorderColor = Color(0xFF334155)
                                    )
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { showNewKeyDialog = false },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Batal", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            if (newKeyNameInput.isNotBlank()) {
                                                val generated = SecurityHelper.generateApiKey()
                                                val newKey = ApiKeyInfo(
                                                    id = "key_${System.currentTimeMillis()}",
                                                    name = newKeyNameInput.trim(),
                                                    key = generated,
                                                    role = newKeyRoleInput,
                                                    createdDate = "Baru Saja",
                                                    lastUsed = "Belum Pernah",
                                                    isActive = true,
                                                    rateLimitRpm = 60
                                                )
                                                apiKeysList = listOf(newKey) + apiKeysList
                                                newKeyNameInput = ""
                                                showNewKeyDialog = false
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Simpan & Aktifkan Kunci", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Key List
                    apiKeysList.forEach { keyItem ->
                        val isRevealed = revealedKeys.contains(keyItem.id)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, if (keyItem.isActive) Color(0xFF334155) else Color(0xFF7F1D1D), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(keyItem.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text("${keyItem.role} • Limit: ${keyItem.rateLimitRpm} RPM", fontSize = 9.sp, color = Color(0xFF38BDF8))
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (keyItem.isActive) "AKTIF" else "REVOKED",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (keyItem.isActive) Color(0xFF34D399) else Color(0xFFEF4444)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Switch(
                                            checked = keyItem.isActive,
                                            onCheckedChange = { active ->
                                                apiKeysList = apiKeysList.map {
                                                    if (it.id == keyItem.id) it.copy(isActive = active) else it
                                                }
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = Color(0xFF059669),
                                                uncheckedThumbColor = Color(0xFF94A3B8),
                                                uncheckedTrackColor = Color(0xFF334155)
                                            ),
                                            modifier = Modifier.size(34.dp)
                                        )
                                    }
                                }

                                // Key display box
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF0F172A))
                                        .padding(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (isRevealed) keyItem.key else "${keyItem.key.take(10)}••••••••••••••••${keyItem.key.takeLast(4)}",
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = if (keyItem.isActive) Color(0xFFE2E8F0) else Color(0xFF94A3B8)
                                        )

                                        Row {
                                            IconButton(
                                                onClick = {
                                                    revealedKeys = if (isRevealed) revealedKeys - keyItem.id else revealedKeys + keyItem.id
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (isRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = null,
                                                    tint = Color(0xFF94A3B8),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            IconButton(
                                                onClick = {
                                                    AttendanceExportHelper.copyToClipboard(context, keyItem.key, "API Key")
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ContentCopy,
                                                    contentDescription = null,
                                                    tint = Color(0xFF38BDF8),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = "Dibuat: ${keyItem.createdDate} • Terakhir digunakan: ${keyItem.lastUsed}",
                                    fontSize = 8.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: WEBHOOK & ERP SYNC
        if (apiSection == "WEBHOOK") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Sync, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🔗 Webhook & Integrasi ERP Otomatis",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Text(
                        text = "Kirim notifikasi otomatis ke server eksternal saat karyawan melakukan absensi, mengajukan cuti, atau terdeteksi ancaman keamanan.",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )

                    Text("Target Webhook URL:", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    OutlinedTextField(
                        value = webhookUrl,
                        onValueChange = { webhookUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )

                    Text("Pemicu Event (Triggers):", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("attendance.checkin (Presensi Berhasil)", fontSize = 11.sp, color = Color.White)
                            Switch(
                                checked = isWebhookAttendanceChecked,
                                onCheckedChange = { isWebhookAttendanceChecked = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF0284C7),
                                    uncheckedThumbColor = Color(0xFF94A3B8),
                                    uncheckedTrackColor = Color(0xFF334155)
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("approval.created (Pengajuan Cuti/Lembur)", fontSize = 11.sp, color = Color.White)
                            Switch(
                                checked = isWebhookLeaveChecked,
                                onCheckedChange = { isWebhookLeaveChecked = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF0284C7),
                                    uncheckedThumbColor = Color(0xFF94A3B8),
                                    uncheckedTrackColor = Color(0xFF334155)
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("security.threat_alert (Peringatan Hack/Mock GPS)", fontSize = 11.sp, color = Color.White)
                            Switch(
                                checked = isWebhookSecurityChecked,
                                onCheckedChange = { isWebhookSecurityChecked = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFEF4444),
                                    uncheckedThumbColor = Color(0xFF94A3B8),
                                    uncheckedTrackColor = Color(0xFF334155)
                                )
                            )
                        }
                    }

                    Button(
                        onClick = {
                            isTestingWebhook = true
                            scope.launch {
                                delay(400)
                                webhookTestResult = "✅ Webhook Ping Sukses (HTTP 200 OK) ke $webhookUrl • HMAC-Signature: sha256=9f82... • Response time: 48ms"
                                isTestingWebhook = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isTestingWebhook,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        if (isTestingWebhook) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Menguji Koneksi...", fontSize = 11.sp)
                        } else {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Uji Coba Ping Webhook", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    webhookTestResult?.let { msg ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF064E3B))
                                .border(1.dp, Color(0xFF059669), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(text = msg, color = Color(0xFFA7F3D0), fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
